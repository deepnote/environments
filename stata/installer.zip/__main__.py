""" Main script for install the Deepnote environment. """

import logging
import os
import shutil
import sys
import sysconfig
import textwrap
from typing import List

from module.constants import BASH_PROMPT_SCRIPT, GIT_SSH_COMMAND
from module.downloader import load_toolkit_bundle
from module.helper import (
    append_to_file,
    generate_kernel_config,
    get_kernel_site_package_path,
    get_server_site_package_path,
    parse_arguments,
)
from module.kernels import setup_non_python_kernels
from module.server_process import ServerProcess
from module.streamlit import start_streamlit_servers
from module.symlinks import (
    create_home_work_symlink,
    create_python_symlink,
    create_work_symlink,
)
from module.types import StartServerConfig
from module.virtual_environment import VirtualEnvironment

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="[setup.py] [%(asctime)s]: %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
    handlers=[logging.StreamHandler(sys.stdout)],
)

logger = logging.getLogger()


def setup_config_dir(root_path: str, target_path="/deepnote-configs"):
    """
    Setup the configuration files for the Deepnote environment.
    """
    logger.info("Setting up configuration files")
    # Copy the configuration files
    shutil.copytree(os.path.join(root_path, "configs"), target_path, dirs_exist_ok=True)
    return target_path


def configure_git_ssh():
    """
    Configure the Git SSH command if it is not already set.
    """
    if "GIT_SSH_COMMAND" not in os.environ:
        os.environ["GIT_SSH_COMMAND"] = GIT_SSH_COMMAND
    else:
        logger.warning("GIT_SSH_COMMAND already set")


def configure_github_https(config_dir_path: str):
    """
    Configure GitHub to use HTTPS for authentication.
    """
    logger.info("Creating gitconfig file")
    github_credential_helper_path = os.path.join(
        config_dir_path, "scripts", "github_credential_helper.py"
    )
    github_config = f"""
    [credential "https://github.com"]
    useHttpPath = true
    helper = {github_credential_helper_path}
    """

    append_to_file("/etc/gitconfig", textwrap.dedent(github_config).strip())


def set_jupyter_ipython_configs(
    venv: VirtualEnvironment, toolkit_bundle_path: str, config_directory_path: str
):
    """
    Set the Jupyter and IPython configuration paths.
    """
    logger.info("Setup config paths for jupyter and ipython")
    # In case of utilaizing cache, config is on read only drive. So we copy
    # the config to writable location

    ipython_config_path = os.path.join(config_directory_path, "ipython")
    jupyter_config_path = os.path.join(config_directory_path, "jupyter")

    jupyter_path_server_bundle = os.path.join(
        toolkit_bundle_path, "server-libs", "share", "jupyter"
    )
    jupyter_path_deepnote_config = os.path.join(config_directory_path, "jupyter")

    jupyter_bin_path = os.path.join(
        toolkit_bundle_path,
        "server-libs",
        "bin",
    )

    os.environ["IPYTHONDIR"] = ipython_config_path
    os.environ["JUPYTER_CONFIG_DIR"] = jupyter_config_path
    os.environ["JUPYTER_PREFER_ENV_PATH"] = "0"

    kernel_config_directory = os.path.join(
        jupyter_path_deepnote_config, "kernels", "python3-venv"
    )
    os.makedirs(kernel_config_directory, exist_ok=True)

    with open(
        os.path.join(kernel_config_directory, "kernel.json"), "w", encoding="utf-8"
    ) as file:
        file.write(generate_kernel_config(f"{jupyter_config_path}/kernel-startup.sh"))

    os.environ["DEEPNOTE_VENV_SITE_PACKAGES_PATH"] = venv.site_packages_path
    os.environ["PATH"] = f"{os.environ['PATH']}:{jupyter_bin_path}"
    if "JUPYTER_PATH" in os.environ:
        os.environ["JUPYTER_PATH"] = (
            f"{jupyter_path_deepnote_config}:{os.environ['JUPYTER_PATH']}:{jupyter_path_server_bundle}"
        )
    else:
        os.environ["JUPYTER_PATH"] = (
            f"{jupyter_path_deepnote_config}:{jupyter_path_server_bundle}"
        )

    venv.append_env_variable("PATH", "$PATH:" + os.environ["PATH"])
    venv.append_env_variable("JUPYTER_PATH", os.environ["JUPYTER_PATH"])
    venv.append_env_variable("IPYTHONDIR", os.environ["IPYTHONDIR"])
    venv.append_env_variable("JUPYTER_CONFIG_DIR", os.environ["JUPYTER_CONFIG_DIR"])
    venv.append_env_variable("JUPYTER_PREFER_ENV_PATH", "0")


def configure_profile(venv: VirtualEnvironment):
    """
    Set the prompt script for the virtual
    """
    logger.info("Configuring prompt")
    profile_content = BASH_PROMPT_SCRIPT + "\n" + f". {venv.activate_file_path}"
    append_to_file("~/.profile", profile_content)


def prepare_servers_to_start(venv: VirtualEnvironment, config: StartServerConfig):
    """
    Prepare servers for start based on the configuration.
    """

    server_processes: List[ServerProcess] = []
    if config.start_jupyter:
        # Start Jupyter server logic here
        server_processes.append(venv.start_server("jupyter notebook --allow-root"))

    if config.start_ls:
        # Start language server logic here
        server_processes.append(
            venv.start_server("python -m pyls --tcp --host 0.0.0.0 -v")
        )
    if config.start_streamlit:
        # Start Streamlit server logic here
        streamlit_processes = start_streamlit_servers(venv, logger)
        server_processes = server_processes + streamlit_processes

    return server_processes


def bootstrap():
    """
    Server bootstrapping function. Parses arguments and sets up the Deepnote environment.
    """

    # Phase 1: Parse arguments
    args = parse_arguments()

    # Phase 1: Load the toolkit bundle
    if args.bundle_path is None:
        toolkit_bundle_path = load_toolkit_bundle(
            args,
        )
    else:
        toolkit_bundle_path = args.bundle_path

    config_directory_path = setup_config_dir(toolkit_bundle_path)

    # Phase 2: Create symlinks for python and work
    create_work_symlink(args.work_mountpoint)
    create_home_work_symlink()
    create_python_symlink()

    # Phase 3: Create the virtual environment
    venv = VirtualEnvironment(args.venv_path)
    venv.create()

    # Phase 4: Setup import paths for the virtual environment
    # Phase 4.1: Import site packages
    system_site_packages_path = sysconfig.get_path("purelib")
    server_site_packages_path = get_server_site_package_path(toolkit_bundle_path)
    kernel_site_package_path = get_kernel_site_package_path(toolkit_bundle_path)

    venv.import_package_bundle(server_site_packages_path)
    venv.import_package_bundle(system_site_packages_path)
    venv.import_package_bundle(kernel_site_package_path)

    # Phase 4.2: Set a server site package path to env variable
    os.environ["DEEPNOTE_SERVER_SIDE_PACKAGES_PTH"] = server_site_packages_path

    # Phase 5: Set up the environment variables for Jupyter and IPython
    set_jupyter_ipython_configs(venv, toolkit_bundle_path, config_directory_path)

    # Phase 6: Create necessary configurations files in a pod
    configure_git_ssh()
    configure_github_https(config_directory_path)
    configure_profile(venv)

    if not args.python_kernel_only:
        setup_non_python_kernels(venv, config_directory_path)

    logger.info("Preparation of the environment was successful. Starting server...")

    # Phase 7: Define the server processes to start
    args = StartServerConfig(
        start_jupyter=args.start_jupyter,
        start_ls=args.start_ls,
        start_streamlit=args.start_streamlit_servers,
    )
    server_processes = prepare_servers_to_start(venv, args)

    prometheus_script = os.path.join(
        config_directory_path, "scripts", "prometheus_metrics.py"
    )
    server_processes.append(venv.start_server(f"python {prometheus_script}"))

    return server_processes


def start_servers(server_processes: List[ServerProcess]):
    """Start the Jupyter server."""

    # Start all the servers
    for server_process in server_processes:
        server_process.start()

    # Wait for all the servers to finish
    for server_process in server_processes:
        server_process.wait()


if __name__ == "__main__":
    servers = bootstrap()

    start_servers(servers)
