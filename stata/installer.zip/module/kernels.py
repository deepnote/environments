""" This module provides functions to manage Jupyter kernels. """

import json
import logging
import os

from module.helper import append_to_file

from .virtual_environment import VirtualEnvironment

logger = logging.getLogger(__name__)


def setup_non_python_kernels(venv: VirtualEnvironment, config_directory_path: str):
    """
    User environment can be configured in a way where also non python kernels are available.
    For example user can user R or Stata kernels.

    For all non-Python kernels, our standard approach to inserting integration environment
    variables does not work.We need to add the environment variables to the kernel before
    Jupyter starts to ensure that all kernels will inherit the integration environment variables.
    [TODO: Find more native solution]

    This function will setup the IR kernel if it is available.
    """

    logger.info("[Setup non python kernels] Checking for existing kernels")
    kernels = list_available_kernels(venv)
    logger.info("[Setup non python kernels] Kernels found: %s", kernels)

    non_python_kernel_exists = any("python" not in kernel for kernel in kernels)

    if non_python_kernel_exists:
        logger.info(
            "[Setup non python kernels] Found non python kernel. "
            "Setting command to fetch integration variables in venv activation"
        )
        integration_vars_script_path = os.path.join(
            config_directory_path, "scripts/get_integration_vars.py"
        )
        append_to_file(
            venv.activate_file_path,
            f'eval "$({integration_vars_script_path})"',
        )
        logger.info(
            "[Setup non python kernels] Integration variables script added to venv activation"
        )

    if "ir" in kernels:
        logger.info(
            "[Setup non python kernels] IR kernel detected. Running setup logic."
        )
        setup_ir_kernel()
        logger.info("[Setup non python kernels] IR kernel setup complete.")


def list_available_kernels(venv: VirtualEnvironment):
    """
    List all available Jupyter kernels in the given virtual environment.

    Parameters:
    venv (VirtualEnvironment): The virtual environment in which to list the kernels.

    Returns:
    list: A list of available kernel names.
    """
    try:
        # Execute the command to list kernels in JSON format
        output = venv.execute("jupyter kernelspec list --json")
        # Parse the JSON output
        kernelspec_data = json.loads(output)
        # Extract and return the kernel names
        return list(kernelspec_data["kernelspecs"].keys())
    except json.JSONDecodeError as e:
        # Handle JSON decoding errors
        print(f"Error decoding JSON output: {e}")
    except Exception as e:
        # Handle other exceptions
        print(f"An error occurred while listing kernels: {e}")
    return []


def setup_ir_kernel():
    """
    Setup the IR kernel if it is available.
    """
    os.environ["R_LIBS"] = "/work/.R/library"
    append_to_file("~/.Rprofile", "setwd('~/work')")
