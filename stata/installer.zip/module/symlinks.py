""" Module to create symlinks as part of installing toolkit."""

import logging
import os
import shutil

logger = logging.getLogger(__name__)


def create_work_symlink(work_mountpoint: str) -> None:
    """
    Create a symlink for /work. The original source of the data is mounted at work_mountpoint.
    """
    is_dev_mode = (
        os.environ.get("DEEPNOTE_RUNNING_IN_DEV_MODE", "false").lower() == "true"
    )
    project_id = os.environ.get("PROJECT_ID")

    if is_dev_mode and project_id:
        if os.path.islink("/work"):
            os.unlink("/work")

        # In dev mode, all projects are mounted under /datasets/_deepnote_work/projects.
        # If project_id is available, create a symlink to the project-specific path.
        project_specific_path = os.path.join(work_mountpoint, "projects", project_id)

        logger.info("Creating symlink for /work pointing to %s", project_specific_path)

        os.symlink(project_specific_path, "/work")
        return

    if os.path.exists("/work") or os.path.ismount("/work") or os.path.islink("/work"):
        logger.warning("/work already exists; not creating symlink.")
    else:
        logger.info("Creating symlink for /work pointing to /datasets/_deepnote_work")
        os.symlink(work_mountpoint, "/work")


def create_home_work_symlink() -> None:
    """
    Create a symlink from the user's home directory (~/work) to the /work directory.
    This supports user custom settings by linking the home work directory to the known /work directory.
    """
    home_work_path = os.path.expanduser("~/work")

    if os.path.islink(home_work_path):
        os.unlink(home_work_path)
    else:
        shutil.rmtree(home_work_path, ignore_errors=True)

    os.symlink("/work", home_work_path)
    logger.info("Successfully created symlink from ~/work to /work.")


def create_python_symlink() -> None:
    """
    Create a symlink for python in /usr/local/bin if it does not already exist.
    """
    python_symlink_path = "/usr/local/bin/python"
    if not os.path.isfile(python_symlink_path):
        logger.info("Creating symlink for python")
        python_path = shutil.which("python")
        if python_path:
            os.symlink(python_path, python_symlink_path)
        else:
            logger.error("Python executable not found.")
    else:
        logger.warning("Symlink for python already exists.")
