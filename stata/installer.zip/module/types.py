""" This module contains the Config dataclass. """

import dataclasses
from typing import Optional


@dataclasses.dataclass
class InstallerConfig:
    """
    Configuration for the installer.
    """

    # Declare class attributes with type hints
    work_mountpoint: str
    venv_path: str
    version: str

    start_jupyter: bool
    start_ls: bool
    start_streamlit_servers: bool
    python_kernel_only: bool

    # URL where installer can download toolkit
    index_url: Optional[str]
    # Local filesystem path where cache is mounted
    cache_path: Optional[str]
    # The path to the toolkit bundle on the local file system.
    bundle_path: Optional[str]


@dataclasses.dataclass
class StartServerConfig:
    """
    Configuration for starting servers.
    """

    start_jupyter: bool
    start_ls: bool
    start_streamlit: bool
