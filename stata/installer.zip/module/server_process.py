""" Module to manage a server process. """

import logging
import os
import subprocess
import sys
import threading

logger = logging.getLogger(__name__)


class ServerProcess:
    """A class to manage a server process."""

    def __init__(self, command: str, cwd: str = None):
        """
        Initialize the ServerProcess with the given command.

        :param command: The command to start the server.
        """
        self.command = command
        self.cwd = cwd
        self.process = None
        self.stdout_thread = None
        self.stderr_thread = None

    def start(self) -> subprocess.Popen:
        """
        Start the server process using the specified command.

        :return: The started process.
        """
        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"

        logger.info("Starting the server via command: %s", self.command)
        self.process = subprocess.Popen(
            self.command,
            cwd=self.cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            stdin=subprocess.PIPE,
            bufsize=0,
            env=env,
            universal_newlines=True,
            shell=True,
        )

        # Start threads to read stdout and stderr
        self.stdout_thread = threading.Thread(target=self._read_output)
        self.stderr_thread = threading.Thread(target=self._read_error)

        self.stdout_thread.start()
        self.stderr_thread.start()

        return self.process

    def terminate(self) -> None:
        """
        Terminate the server process and ensure all output is processed.
        """
        if self.process:
            logger.info("Terminating the server process: %s", self.command)
            self.process.terminate()

            # Join the threads to make sure all output is processed
            self.stdout_thread.join()
            self.stderr_thread.join()

            # Close the streams
            self.process.stdout.close()
            self.process.stderr.close()

    def wait(self) -> None:
        """
        Wait for the server process to complete and join the threads.
        """
        try:
            # Wait for the server process to complete
            self.process.wait()
        except KeyboardInterrupt:
            self.terminate()

        self.stdout_thread.join()
        self.stderr_thread.join()

    def _read_output(self) -> None:
        """
        Read the process output in real time and write it to stdout.
        """
        for line in iter(self.process.stdout.readline, ""):
            if line:
                sys.stdout.write(line)
                sys.stdout.flush()  # Ensure that the output is flushed immediately

    def _read_error(self) -> None:
        """
        Read the process error in real time and write it to stderr.
        """
        for line in iter(self.process.stderr.readline, ""):
            if line:
                sys.stderr.write(line)
                sys.stderr.flush()  # Ensure that the error is flushed immediately
