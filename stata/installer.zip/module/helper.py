""" Helper functions for the package setup script. """

import argparse
import json
import logging
import os
import sys
import time
import urllib
from urllib.error import HTTPError, URLError

from .types import InstallerConfig

logger = logging.getLogger(__name__)


def get_current_python_version() -> str:
    """
    Get the current Python version in 'major.minor' format.

    :return: The current Python version.
    """
    return ".".join(map(str, sys.version_info[:2]))


def get_kernel_site_package_path(
    root_path: str,
) -> str:
    """
    Returns the path to the site package directory with libraries for kernel.
    :param root_path: Root of the bundle.
    :return: The path to the libraries for kernel .
    """
    root_path_expanded = os.path.expanduser(root_path)
    return os.path.join(
        root_path_expanded,
        "kernel-libs",
        "lib",
        f"python{get_current_python_version()}",
        "site-packages",
    )


def get_config_path(root_path: str) -> str:
    """
    Returns the path to the config directory.
    :param root_path: Root of the bundle.
    :return: The path to the config directory.
    """
    root_path_expanded = os.path.expanduser(root_path)
    return os.path.join(
        root_path_expanded,
        "config",
    )


def get_server_site_package_path(
    root_path: str,
) -> str:
    """
    Returns the path to the site package directory with libraries for server.
    :param root_path: Root of the bundle.
    :return: The path to the libraries for server .
    """
    root_path_expanded = os.path.expanduser(root_path)
    return os.path.join(
        root_path_expanded,
        "server-libs",
        "lib",
        f"python{get_current_python_version()}",
        "site-packages",
    )


def append_to_file(file_path: str, content: str) -> None:
    """
    Append content to a file if it does not already exist in the file.

    :param file_path: The path to the file.
    :param content: The content to append.
    """
    file_path_expanded = os.path.expanduser(file_path)
    try:
        with open(file_path_expanded, "r", encoding="utf8") as file:
            lines = file.read().splitlines()
    except FileNotFoundError:
        lines = []

    if content not in lines:
        with open(file_path_expanded, "a", encoding="utf8") as file:
            file.write(content + "\n")
    else:
        print(f"Content already in {file_path_expanded}")


def generate_kernel_config(kernel_startup_script_path: str) -> str:
    """
    Generate a kernel configuration for the virtual environment.
    """
    return json.dumps(
        {
            "argv": [
                "/bin/sh",
                kernel_startup_script_path,
                "{connection_file}",
            ],
            "display_name": "Deepnote Python 3",
            "language": "python",
            "metadata": {"debugger": False},
        }
    )


def parse_arguments() -> InstallerConfig:
    """
    Parse command-line arguments and set configuration values.
    """
    parser = argparse.ArgumentParser(
        description="Setup script for Deepnote environment."
    )
    parser.add_argument(
        "--work-mountpoint",
        default="/datasets/_deepnote_work",
        help="Path to work mountpoint",
    )
    parser.add_argument(
        "--venv-path", default="~/venv", help="Path to virtual environment"
    )
    parser.add_argument(
        "--index-url",
        help="Location where all toolkit versions are stored. DEEPNOTE_TOOLKIT_INDEX_URL",
    )
    parser.add_argument(
        "--version",
        help="Version of the toolkit to install. DEEPNOTE_TOOLKIT_VERSION",
    )
    parser.add_argument(
        "--cache-path",
        help="Path to the toolkit cache. DEEPNOTE_TOOLKIT_CACHE_PATH",
    )
    parser.add_argument(
        "--bundle-path",
        help="Exact path to root toolkit bundle directory",
    )

    parser.add_argument(
        "--python-kernel-only",
        action="store_true",
        default=False,
        help="Only python kernel can be started",
    )

    parser.add_argument(
        "--start-jupyter",
        action="store_true",
        default=False,
        help="Start subprocess with Jupyter server",
    )
    parser.add_argument(
        "--start-ls",
        action="store_true",
        default=False,
        help="Start subprocess with LS server",
    )
    parser.add_argument(
        "--start-streamlit-servers",
        action="store_true",
        default=False,
        help="Start subprocess for streamlit servers",
    )
    parser.add_argument(
        "--start-servers",
        action="store_true",
        default=True,
        help="Start subprocess with all servers",
    )

    args, _ = parser.parse_known_args()

    work_mountpoint = os.path.expanduser(args.work_mountpoint)
    venv_path = os.path.expanduser(os.path.expanduser(args.venv_path))
    bundle_path = os.path.expanduser(args.bundle_path) if args.bundle_path else None

    version = (
        args.version
        or os.getenv("DEEPNOTE_TOOLKIT_VERSION")
        or os.getenv("TOOLKIT_VERSION")
    )
    index_url = (
        args.index_url
        or os.getenv("DEEPNOTE_TOOLKIT_INDEX_URL")
        or os.getenv("TOOLKIT_INDEX_URL")
    )
    cache_path = (
        args.cache_path
        or os.getenv("DEEPNOTE_TOOLKIT_CACHE_PATH")
        or os.getenv("TOOLKIT_CACHE_PATH")
    )

    bundle_path = (
        args.bundle_path
        or os.getenv("DEEPNOTE_TOOLKIT_BUNDLE_PATH")
        or os.getenv("TOOLKIT_BUNDLE_PATH")
    )

    python_kernel_only = (
        args.python_kernel_only
        or os.getenv("DEEPNOTE_PYTHON_KERNEL_ONLY")
        or os.getenv("PYTHON_KERNEL_ONLY")
    )

    if not index_url and not bundle_path and not cache_path:
        raise ValueError(
            "At least one of --index-url, --bundle-path or --cache-path must be set."
        )

    if not version and not bundle_path:
        raise ValueError("Toolkit version must be set")

    return InstallerConfig(
        work_mountpoint=work_mountpoint,
        venv_path=venv_path,
        version=version,
        index_url=index_url,
        cache_path=cache_path,
        bundle_path=bundle_path,
        python_kernel_only=python_kernel_only,
        start_jupyter=args.start_jupyter or args.start_servers,
        start_ls=args.start_ls or args.start_servers,
        start_streamlit_servers=args.start_streamlit_servers or args.start_servers,
    )


def request_with_retries(
    log: logging.Logger, url: str, max_retries=3, backoff=2, timeout=3
) -> str:
    """Retries the request in case of failure."""
    for attempt in range(max_retries):
        try:
            with urllib.request.urlopen(url, timeout=timeout) as response:
                return response.read().decode("utf-8")
        except (HTTPError, URLError) as e:
            log.error(f"Attempt {attempt + 1} failed: {e}")
            if attempt < max_retries - 1:
                time.sleep(backoff * (2**attempt))
            else:
                log.error("Max retries reached. Exiting.")
                raise

    return ""
